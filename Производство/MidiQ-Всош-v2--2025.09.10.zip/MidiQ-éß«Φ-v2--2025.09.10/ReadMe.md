<div align="center">

# MidiQ Всош v2

`Сборка 2025.09.1`

</div>

---

## Форматы файлов

Количество копий деталей указано через префикс `nx` (`2x--Деталь` - 2 шт.)

- 3D-Печать `.3mf` `.stp`
- Лазерная резка `.dxf`

## Основной репозиторий

[https://github.com/JamahaW/OmniCore-Robotics](https://github.com/JamahaW/OmniCore-Robotics)

## Лицензия

**GNU GPL v3.0** [LICENSE](https://github.com/JamahaW/OmniCore-Robotics/blob/main/LICENSE)
